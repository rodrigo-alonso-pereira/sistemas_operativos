#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

/*
 * Este programa cuenta votos de elecciones primarias usando múltiples hebras.
 * Se basa en lectura de un archivo de texto que contiene un voto por línea,
 * distribuye las líneas entre hebras y suma los resultados en un contador global protegido por un mutex.
 */

/* Tamaño máximo de cada línea leída y número de candidatos participantes */
#define MAX_LINE_LEN 20
#define NUM_CANDIDATES 4

/* Lista estática con los nombres de los candidatos */
const char *candidates[NUM_CANDIDATES] = {
    "Carolina Toha",
    "Gonzalo Winter",
    "Jeannette Jara",
    "Jaime Mulet"
};

/* Arreglo global para acumular los votos de cada candidato */
int global_counts[NUM_CANDIDATES] = {0};
/* Mutex para proteger actualizaciones concurrentes a global_counts */
pthread_mutex_t count_mutex;

/* Estructura para pasar datos a cada hebra: puntero al arreglo de votos, índice de inicio y cantidad de votos */
typedef struct {
    char **votes;
    int start;
    int count;
} ThreadData;

/* Función que ejecuta cada hebra: cuenta los votos en su segmento y acumula en el contador global */
void *count_votes(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    /* Contador local para evitar contención frecuente del mutex */
    int local_counts[NUM_CANDIDATES] = {0};
    
    /* Recorre su segmento de votos y suma en local_counts */
    for (int i = 0; i < data->count; i++) {
        char *vote = data->votes[data->start + i];
        for (int j = 0; j < NUM_CANDIDATES; j++) {
            if (strcmp(vote, candidates[j]) == 0) {
                local_counts[j]++;
                break;
            }
        }
    }
    
    /* Bloquea el mutex para actualizar el contador global de forma atómica */
    pthread_mutex_lock(&count_mutex);
    for (int j = 0; j < NUM_CANDIDATES; j++) {
        global_counts[j] += local_counts[j];
    }
    /* Desbloquea el mutex tras la actualización */
    pthread_mutex_unlock(&count_mutex);
      
    /* Libera la estructura de datos reservada para esta hebra */
    free(data);
    return NULL;
}

int main(int argc, char *argv[]) {
    /* Verifica que se reciban los parámetros necesarios: archivo de votos y número de hebras */
    if (argc < 3) {
        fprintf(stderr, "Uso: %s <archivo_votos> <num_hebras>\n", argv[0]);
        return EXIT_FAILURE;
    }

    /* Parámetros de entrada */
    const char *input_file = argv[1];
    int num_threads = atoi(argv[2]);
    if (num_threads <= 0) {
        fprintf(stderr, "Número de hebras debe ser positivo.\n");
        return EXIT_FAILURE;
    }

    /* Abre el archivo de votos en modo lectura */
    FILE *fp = fopen(input_file, "r");
    if (!fp) {
        perror("Error al abrir archivo de votos");
        return EXIT_FAILURE;
    }

    /* Lee todas las líneas del archivo y las guarda en un arreglo dinámico */
    char **votes = NULL;
    int total_votes = 0;
    char line[MAX_LINE_LEN];

    while (fgets(line, sizeof(line), fp)) {
        /* Elimina salto de línea y almacena la cadena */
        line[strcspn(line, "\r\n")] = '\0';
        votes = realloc(votes, (total_votes + 1) * sizeof(char *));
        votes[total_votes] = strdup(line);
        total_votes++;
    }
    fclose(fp);

    /* Inicializa el mutex antes de crear hebras */
    pthread_mutex_init(&count_mutex, NULL);

    /* Reserva arreglo de identificadores de hebra y calcula reparto equitativo */
    pthread_t *threads = malloc(num_threads * sizeof(pthread_t));
    int base = total_votes / num_threads;
    int rem = total_votes % num_threads;

    /* Crea cada hebra pasándole su segmento de trabajo */
    for (int i = 0; i < num_threads; i++) {
        int count = base + (i < rem ? 1 : 0);
        int start = i * base + (i < rem ? i : rem);

        ThreadData *data = malloc(sizeof(ThreadData));
        data->votes = votes;
        data->start = start;
        data->count = count;

        if (pthread_create(&threads[i], NULL, count_votes, data) != 0) {
            perror("Error al crear hebra");
            return EXIT_FAILURE;
        }
    }

    /* Espera a que todas las hebras terminen */
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    free(threads);

    /* Genera el reporte final en un archivo de texto */
    FILE *out = fopen("escrutinio_final.txt", "w");
    if (!out) {
        perror("Error al crear archivo de reporte");
        return EXIT_FAILURE;
    }
    fprintf(out, "Resultados Escrutinio Primarias - 29 Junio 2025:\n\n");
    for (int j = 0; j < NUM_CANDIDATES; j++) {
        fprintf(out, "%s: %d votos\n", candidates[j], global_counts[j]);
    }
    fclose(out);

    /* Modo interactivo para consultar votos por candidato */
    char buffer[MAX_LINE_LEN];
    while (1) {
        printf("Ingrese el nombre del candidato para ver sus votos (o 'salir'): ");
        if (!fgets(buffer, sizeof(buffer), stdin)) break;
        buffer[strcspn(buffer, "\r\n")] = '\0';
        if (strcmp(buffer, "salir") == 0) {
            break;
        }
        int found = 0;
        for (int j = 0; j < NUM_CANDIDATES; j++) {
            if (strcmp(buffer, candidates[j]) == 0) {
                printf("%s tiene %d votos.\n", candidates[j], global_counts[j]);
                found = 1;
                break;
            }
        }
        if (!found) {
            printf("Nombre de candidato no válido.\n");
        }
    }

    /* Libera memoria reservada para los votos y destruye el mutex */
    for (int i = 0; i < total_votes; i++) free(votes[i]);
    free(votes);
    pthread_mutex_destroy(&count_mutex);

    return EXIT_SUCCESS;
}
