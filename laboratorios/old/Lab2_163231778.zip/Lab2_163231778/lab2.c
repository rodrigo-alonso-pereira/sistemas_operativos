#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

// Constantes para la longitud máxima de una línea y la cantidad máxima de jugadores
#define MAX_LINE_LENGTH 256
#define MAX_PLAYERS 200

// Estructura que representa un jugador y la cantidad de veces que fue MVP
typedef struct {
    char name[100];
    int count;
} MVP;

// Lista de jugadores MVP y contador total
MVP mvpList[MAX_PLAYERS];
int totalPlayers = 0;

// Mutex global para proteger acceso concurrente a la lista de MVPs
pthread_mutex_t mutex;

// Lista de líneas del archivo y cantidad total de líneas
char **lines;
int totalLines = 0;

// Estructura de argumentos para las hebras
typedef struct {
    int start;
    int end;
} ThreadArgs;

// Función que actualiza o agrega un jugador MVP a la lista protegida por mutex
void updateMVP(const char *name) {
    pthread_mutex_lock(&mutex);
    for (int i = 0; i < totalPlayers; i++) {
        if (strcmp(mvpList[i].name, name) == 0) {
            mvpList[i].count++;
            pthread_mutex_unlock(&mutex);
            return;
        }
    }
    strcpy(mvpList[totalPlayers].name, name);
    mvpList[totalPlayers].count = 1;
    totalPlayers++;
    pthread_mutex_unlock(&mutex);
}

// Función que ejecuta cada hebra: procesa un rango de líneas para extraer los MVP
void *processLines(void *arg) {
    ThreadArgs *args = (ThreadArgs *)arg;
    for (int i = args->start; i < args->end; i++) {
        char *line = lines[i];
        char *token = strtok(line, ",");
        for (int j = 0; j < 4; j++) token = strtok(NULL, ","); // Saltar a la columna del MVP
        if (token != NULL) {
            token[strcspn(token, "\n")] = 0; // Eliminar salto de línea final
            updateMVP(token);
        }
    }
    return NULL;
}

// Función de comparación para qsort (ordenar por cantidad de premios descendente)
int compareMVPs(const void *a, const void *b) {
    MVP *m1 = (MVP *)a;
    MVP *m2 = (MVP *)b;
    return m2->count - m1->count;
}

int main(int argc, char *argv[]) {
    // Verificar que se pasaron los argumentos correctos
    if (argc != 3) {
        printf("Uso: %s archivo.txt numero_hebras\n", argv[0]);
        return 1;
    }

    // Leer nombre del archivo y número de hebras
    char *filename = argv[1];
    int numThreads = atoi(argv[2]);
    if (numThreads <= 0) {
        printf("Número de hebras inválido.\n");
        return 1;
    }

    // Abrir archivo de entrada
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error al abrir el archivo");
        return 1;
    }

    // Leer líneas del archivo
    lines = malloc(125 * sizeof(char *));
    char buffer[MAX_LINE_LENGTH];
    while (fgets(buffer, sizeof(buffer), file)) {
        lines[totalLines] = strdup(buffer);
        totalLines++;
    }
    fclose(file);

    // Inicializar el mutex
    pthread_mutex_init(&mutex, NULL);

    // Crear hebras y asignarles su rango de trabajo
    pthread_t threads[numThreads];
    ThreadArgs args[numThreads];
    int base = totalLines / numThreads;
    int resto = totalLines % numThreads;
    int index = 0;

    for (int i = 0; i < numThreads; i++) {
        args[i].start = index;
        args[i].end = index + base + (i < resto ? 1 : 0);
        index = args[i].end;
        pthread_create(&threads[i], NULL, processLines, &args[i]);
    }

    // Esperar a que todas las hebras terminen
    for (int i = 0; i < numThreads; i++) {
        pthread_join(threads[i], NULL);
    }

    // Ordenar jugadores por cantidad de premios
    qsort(mvpList, totalPlayers, sizeof(MVP), compareMVPs);

    // Escribir el reporte final en archivo
    FILE *out = fopen("reporte_mvp.txt", "w");
    fprintf(out, "Jugador MVP              | Premios\n");
    fprintf(out, "-------------------------|--------\n");
    for (int i = 0; i < totalPlayers; i++) {
        fprintf(out, "%-25s | %2d\n", mvpList[i].name, mvpList[i].count);
    }
    fclose(out);

    // Liberar memoria y destruir mutex
    for (int i = 0; i < totalLines; i++) {
        free(lines[i]);
    }
    free(lines);
    pthread_mutex_destroy(&mutex);

    return 0;
}