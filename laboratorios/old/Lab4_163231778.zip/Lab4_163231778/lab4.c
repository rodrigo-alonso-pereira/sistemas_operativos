#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define TAMANO_BUFFER   5    // capacidad del buffer
#define NUM_CLIENTES    3    // número de hebras productoras
#define NUM_AGENTES     2    // número de hebras consumidoras
#define TOTAL_TICKETS   20   // total de tickets a generar

int buffer[TAMANO_BUFFER];
int in = 0, out = 0;
int produced_count = 0, consumed_count = 0;

// Semáforos para espacios vacíos (empty), tickets pendientes (full) y mutex binario
sem_t empty, full, mutex;
// Mutex para proteger los contadores produced_count y consumed_count
pthread_mutex_t count_mutex;

void* cliente(void* arg) {
    int id = *((int*)arg);
    free(arg);
    while (1) {
        // Generar ID de ticket de forma única
        pthread_mutex_lock(&count_mutex);
        if (produced_count >= TOTAL_TICKETS) {
            pthread_mutex_unlock(&count_mutex);
            break;
        }
        int ticket = ++produced_count;
        pthread_mutex_unlock(&count_mutex);

        // Insertar en buffer
        sem_wait(&empty);
        sem_wait(&mutex);
          buffer[in] = ticket;
          printf("Cliente %d produjo ticket %d\n", id, ticket);
          in = (in + 1) % TAMANO_BUFFER;
        sem_post(&mutex);
        sem_post(&full);
    }
    return NULL;
}

void* agente(void* arg) {
    int id = *((int*)arg);
    free(arg);
    while (1) {
        // Extraer del buffer
        sem_wait(&full);
        sem_wait(&mutex);
          int ticket = buffer[out];
          out = (out + 1) % TAMANO_BUFFER;
        sem_post(&mutex);
        sem_post(&empty);

        // Si es sentinel, salimos
        if (ticket == -1) break;

        // Procesar ticket
        printf("Agente %d resolvió ticket %d\n", id, ticket);
        pthread_mutex_lock(&count_mutex);
          consumed_count++;
        pthread_mutex_unlock(&count_mutex);
    }
    return NULL;
}

int main() {
    pthread_t prod[NUM_CLIENTES], cons[NUM_AGENTES];

    // Inicializar semáforos
    sem_init(&empty, 0, TAMANO_BUFFER);
    sem_init(&full,  0, 0);
    sem_init(&mutex, 0, 1);
    pthread_mutex_init(&count_mutex, NULL);

    // Crear hebras productoras
    for (int i = 0; i < NUM_CLIENTES; i++) {
        int *id = malloc(sizeof(int));
        *id = i + 1;
        pthread_create(&prod[i], NULL, cliente, id);
    }
    // Crear hebras consumidoras
    for (int i = 0; i < NUM_AGENTES; i++) {
        int *id = malloc(sizeof(int));
        *id = i + 1;
        pthread_create(&cons[i], NULL, agente, id);
    }

    // Esperar a que terminen los clientes
    for (int i = 0; i < NUM_CLIENTES; i++)
        pthread_join(prod[i], NULL);

    // Enviar un “ticket” sentinel (-1) para que cada agente salga
    for (int i = 0; i < NUM_AGENTES; i++) {
        sem_wait(&empty);
        sem_wait(&mutex);
          buffer[in] = -1;
          in = (in + 1) % TAMANO_BUFFER;
        sem_post(&mutex);
        sem_post(&full);
    }

    // Esperar a que terminen los agentes
    for (int i = 0; i < NUM_AGENTES; i++)
        pthread_join(cons[i], NULL);

    // Resumen final
    printf("\nResumen: se produjeron %d tickets. Todos los tickets fueron resueltos.\n",
           consumed_count);

    // Destruir semáforos y mutex
    sem_destroy(&empty);
    sem_destroy(&full);
    sem_destroy(&mutex);
    pthread_mutex_destroy(&count_mutex);

    return 0;
}
